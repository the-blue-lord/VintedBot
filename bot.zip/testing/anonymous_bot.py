import requests

res = requests.get("https://www.vinted.it/items/7984451000")

print(res.text)