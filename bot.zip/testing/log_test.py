import console
import hashlib

for _ in range(1):
    console.log("Test logging")
    console.error("this is an error\nand this is the same error")
    console.debug("this is a debug\nand this is the same debug")
    console.warning("this is a warning\nand this is the same warning")
    console.log("test\nrgaregr\njewtrgew", hashlib.md5("test".encode()).hexdigest())
    console.debug("test\nrgaregr\njewtrgew", hashlib.md5("test".encode()).hexdigest())
