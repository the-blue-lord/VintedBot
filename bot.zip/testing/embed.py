import asyncio
import utils.vinted_db_scraper

async def main():
    data = await utils.vinted_db_scraper.asyncGetItem("7998677588")
    print(data)

# Run the async main function
asyncio.run(main())
