from utils.offers_processer import check_new_offers

results = check_new_offers([{"search_text": "garmin forerunner 55 - testing"}, {"search_text": "garmin forerunner 55 - testing"}, {"search_text": "garmin forerunner 55 - testing", "id": 72}])